from django.urls import path
#from api import views
#from . import views  # Import your views from the current directory

urlpatterns = [
    # Define your URL patterns here
   # path('login/', views.login_api, name='login_api'),
    # Add other URLs for your base app here
]
