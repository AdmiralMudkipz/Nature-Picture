from django.urls import path
from .views import LoginAPIView, RefreshTokenView

urlpatterns = [
    path('login/', LoginAPIView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', RefreshTokenView.as_view(), name='token_refresh'),
]